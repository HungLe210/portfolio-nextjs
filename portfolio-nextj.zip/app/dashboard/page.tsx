import React from 'react'

const page = () => {
    return (
        <div>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
            <h1 className='text-white text-2xl'>ADSJJDAAD</h1>
        </div>
    )
}

export default page