import Movies from '@/components/main/Movies';
import ProjectCard from '@/components/sub/ProjectCard';
import React from 'react'




const About = async () => {
    return (
        <Movies />
    )
}

export default About